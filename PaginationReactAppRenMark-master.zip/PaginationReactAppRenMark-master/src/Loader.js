import React, { Component } from "react";

function Loader() {
  return (
    <div className="loader">
      <div className="loader-msg" >Loading data..</div>
    </div>
  );
}

export default Loader;
