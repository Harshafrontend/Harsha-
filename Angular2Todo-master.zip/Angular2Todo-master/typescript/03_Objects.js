"use strict";
exports.__esModule = true;
var _02_class_1 = require("./02_class");
var Ravi = new _02_class_1.Person("Ravi", "Kiran", 20);
console.log(Ravi);
