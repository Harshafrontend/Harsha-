import {Person} from "./02_class";

var Ravi = new Person("Ravi","Kiran",20);
console.log(Ravi);