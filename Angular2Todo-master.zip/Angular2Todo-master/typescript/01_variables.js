/**
 * Datatypes in Typescript
 * 1) Number
 * 2) String
 * 3) Boolean
 * 4) Null
 * 5) Undefined
 */
var firstName = "Raj";
var age = 30;
var value;
value = 10;
value = "sds";
if (true) {
    var lastName = "Kiran";
}
console.log(lastName);
